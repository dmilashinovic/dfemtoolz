
Hello and thank you for your interest in dfemtoolz


In this package user can find the C++ source code and linux executable files for benchmark set of the dfemtoolz software written by Danko Milasinovic. 

This package includes (in short words):

* dfemtoolz_dMyLib - library that is made for this software

* dfemtoolz_remesh - tool that creates [re]mesh using existing mesh (usually import from tetgen, or other similar software).

* dfemtoolz_openR - tool that is able to set various boundary conditions and loads to the finite element model (this software is able to print various data concerning the mesh, and to make different outputs / formats)

Input data for the benchmark tests can be downloaded from here:

https://drive.google.com/open?id=1tw77pLaxzF-8NuDjQ1AEb7apVMMJhGQ7
https://drive.google.com/open?id=1hCdwhSYS-xHHiVd4xd2nHEL3RN_qE2H6

User can, naturally use its own data for benchmarking as well.

This software is available for public under GNU GPLv3 license. Please use it according to the license.


Thank you for your interest
dmilashinovic ..::at::.. gmail.com
