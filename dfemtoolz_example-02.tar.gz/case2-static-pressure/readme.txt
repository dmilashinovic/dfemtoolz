This is static-pressure example readme

In order to use this example, Gmsh software installed on his/hers computer (with Linux or Windows os). Than user should open each of directories in sequential order (00, 01...), and follow the set of commands written in commands.txt/commands.txt.pdf. Commands are written one by one, and not in script, so that user can understand what he/she is doing rather than just to have "jobs done". This is important because at the end user should be familiar enough with the software to be able to include it to his/hers own project, or to use it stand-alone adequately.

If user wants to look the final results without any procedure - please unzip final-output.zip.


Thank you for your interest
dmilashinovic ..::at::.. gmail.com
